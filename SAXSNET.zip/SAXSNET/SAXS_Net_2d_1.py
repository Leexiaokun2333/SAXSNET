import torch.nn as nn
import torch
import numpy as np


class saxs_net(nn.Module):
    def __init__(self):
        super(saxs_net, self).__init__()
        # 构建卷积层
        self.conv = nn.Sequential(
            # 输入通道数，输出通道数，卷积核尺寸，步长，padding
            nn.Conv2d(1, 16, 6, 2, 3),  # [36, 16, 2, 251]
            nn.BatchNorm2d(16),
            nn.LeakyReLU(inplace=True),  # inplace = True ,会改变输入数据的值,节省反复申请与释放内存的空间与时间,只是将原来的地址传递,效率更好
            nn.MaxPool2d(4, 2, padding=2),  # 卷积核尺寸, [36, 16, 2, 126]

            nn.Conv2d(16, 32, 4, 2, 3),  # [36, 32, 3, 126]
            nn.BatchNorm2d(32),
            nn.LeakyReLU(inplace=True),  # inplace = True ,会改变输入数据的值,节省反复申请与释放内存的空间与时间,只是将原来的地址传递,效率更好
            nn.MaxPool2d(4, 2, padding=2),  # 卷积核尺寸, [36, 32, 2, 33]
            # # 减小卷积窗口，使用填充padding为2来使得输入与输出的高和宽一致，且增大输出通道数
            nn.Conv2d(32, 64, 3, 1, padding=1),  # [36, 64, 2, 33]
            nn.BatchNorm2d(64),
            nn.LeakyReLU(inplace=True),
            nn.MaxPool2d(3, 1, padding=1),  # [36, 64, 2, 33]
            # # 连续4个卷积层，且使用更小的卷积窗口，除了最后的卷积层外，进一步增大了输出通道数
            nn.Conv2d(64, 192, 3, padding=1),  # [36, 192, 2, 33]
            nn.BatchNorm2d(192),
            nn.LeakyReLU(inplace=True),
            nn.Conv2d(192, 384, 3, padding=1),  # [36, 384, 2, 33]
            nn.BatchNorm2d(384),
            nn.LeakyReLU(inplace=True),
            # nn.Conv2d(384, 256, 3, padding=1),  # [36, 256, 2, 33]
            # nn.BatchNorm2d(256),
            # nn.LeakyReLU(inplace=True),
            # nn.Conv2d(256, 256, 3, padding=1),  # [36, 256, 2, 33]
            # nn.BatchNorm2d(256),
            # nn.LeakyReLU(inplace=True),
            nn.MaxPool2d(2, 1),  # [36, 256, 1, 32]
            nn.Flatten()  # [36, 8192]   [36, 12288]
        )

        self.fc = nn.Sequential(
            nn.Dropout(0.3),
            nn.Linear(12288, 4096),
            nn.LeakyReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(4096, 4096),
            nn.LeakyReLU(inplace=True),
            nn.Dropout(0.1),
            nn.Linear(4096, 4),
        )

    def forward(self, data):
        data = data.to(torch.float32)
        feature = self.conv(data)

        feature = self.fc(feature)
        return feature


# # 生成随机数矩阵测试网络
# fd = np.random.rand(36, 2, 500)
# # print(fd)
#
# fd = torch.as_tensor(fd)
# fd = torch.unsqueeze(fd, dim=1)  # 行升维
# print(fd.shape)
# net = saxs_net()
# output = net(fd)
# # print(output)
# print(output.shape)  # torch.Size([36, 4])
