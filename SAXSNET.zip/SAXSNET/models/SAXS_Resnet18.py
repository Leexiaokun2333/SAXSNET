import torch
import torch.nn as nn
from torch.nn import functional as F
from torch.utils.data import SubsetRandomSampler
import numpy as np


class ResNetBasicBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride):
        super(ResNetBasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=stride, padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)

    def forward(self, x):
        output = self.conv1(x)
        output = F.relu(self.bn1(output))
        output = self.conv2(output)
        output = self.bn2(output)
        return F.relu(x + output)


class ResNetDownBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride):
        super(ResNetDownBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride[0], padding=1)
        self.bn1 = nn.BatchNorm2d(out_channels)
        self.conv2 = nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=stride[1], padding=1)
        self.bn2 = nn.BatchNorm2d(out_channels)
        self.extra = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, stride=stride[0], padding=0),
            nn.BatchNorm2d(out_channels)
        )

    def forward(self, x):
        extra_x = self.extra(x)
        output = self.conv1(x)
        out = F.relu(self.bn1(output))

        out = self.conv2(out)
        out = self.bn2(out)
        return F.relu(extra_x + out)


class SAXS_ResNet18(nn.Module):
    def __init__(self):
        super(SAXS_ResNet18, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=6, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = nn.Sequential(
            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1)
        )

        self.layer2 = nn.Sequential(
            ResNetDownBlock(64, 128, [2, 1]),
            ResNetBasicBlock(128, 128, 1)
        )

        self.layer3 = nn.Sequential(
            ResNetDownBlock(128, 256, [2, 1]),
            ResNetBasicBlock(256, 256, 1)
        )

        self.layer4 = nn.Sequential(
            ResNetDownBlock(256, 512, [2, 1]),
            ResNetBasicBlock(512, 512, 1)
        )

        self.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))

        self.fc = nn.Linear(512, 4)  # 用于分类，四分类

    def forward(self, x):
        x = x.to(torch.float32)  # RuntimeError: expected scalar type Double but found Float
        out = self.conv1(x)  # torch.Size([36, 64, 2, 251])
        out = self.layer1(out)  # torch.Size([36, 64, 2, 251])
        out = self.layer2(out)  # torch.Size([36, 128, 1, 126])
        out = self.layer3(out)  # torch.Size([36, 256, 1, 63])
        out = self.layer4(out)  # torch.Size([36, 512, 1, 32])
        out = self.avgpool(out)  # torch.Size([36, 512, 1, 1])
        out = out.reshape(x.shape[0], -1)  # torch.Size([36, 512])
        out = self.fc(out)  # torch.Size([36, 4])
        return out

    def freeze_backbone(self):
        backbone = [self.conv1, self.layer1, self.layer2, self.layer3, self.layer4]
        for module in backbone:
            for param in module.parameters():
                param.requires_grad = False

    def Unfreeze_backbone(self):
        backbone = [self.conv1, self.layer1, self.layer2, self.layer3, self.layer4]
        for module in backbone:
            for param in module.parameters():
                param.requires_grad = True


class SAXS_ResNet18_size(nn.Module):
    def __init__(self):
        super(SAXS_ResNet18_size, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=6, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = nn.Sequential(
            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1)
        )

        self.layer2 = nn.Sequential(
            ResNetDownBlock(64, 128, [2, 1]),
            ResNetBasicBlock(128, 128, 1)
        )

        self.layer3 = nn.Sequential(
            ResNetDownBlock(128, 256, [2, 1]),
            ResNetBasicBlock(256, 256, 1)
        )

        self.layer4 = nn.Sequential(
            ResNetDownBlock(256, 512, [2, 1]),
            ResNetBasicBlock(512, 512, 1)
        )

        self.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))

        self.fc = nn.Linear(512, 1)  # 用于回归

    def forward(self, x):
        # x = x.to(torch.float32)  # RuntimeError: expected scalar type Double but found Float
        out = self.conv1(x)  # torch.Size([36, 64, 2, 251])
        out = self.layer1(out)  # torch.Size([36, 64, 2, 251])
        out = self.layer2(out)  # torch.Size([36, 128, 1, 126])
        out = self.layer3(out)  # torch.Size([36, 256, 1, 63])
        out = self.layer4(out)  # torch.Size([36, 512, 1, 32])
        out = self.avgpool(out)  # torch.Size([36, 512, 1, 1])
        out = out.reshape(x.shape[0], -1)  # torch.Size([36, 512])
        out = self.fc(out)  # torch.Size([36, 4])
        return out

    def freeze_backbone(self):
        backbone = [self.conv1, self.bn1, self.layer1, self.layer2, self.layer3, self.layer4]
        for module in backbone:
            for param in module.parameters():
                param.requires_grad = False

    def Unfreeze_backbone(self):
        backbone = [self.conv1, self.bn1, self.layer1, self.layer2, self.layer3, self.layer4]
        for module in backbone:
            for param in module.parameters():
                param.requires_grad = True


class SAXS_ResNet34(nn.Module):
    def __init__(self):
        super(SAXS_ResNet34, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=6, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = nn.Sequential(
            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1),

            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1),

            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1)
        )

        self.layer2 = nn.Sequential(
            ResNetDownBlock(64, 128, [2, 1]),
            ResNetBasicBlock(128, 128, 1),

            ResNetBasicBlock(128, 128, 1),
            ResNetBasicBlock(128, 128, 1),

            ResNetBasicBlock(128, 128, 1),
            ResNetBasicBlock(128, 128, 1),

            ResNetBasicBlock(128, 128, 1),
            ResNetBasicBlock(128, 128, 1)
        )

        self.layer3 = nn.Sequential(
            ResNetDownBlock(128, 256, [2, 1]),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1)
        )

        self.layer4 = nn.Sequential(
            ResNetDownBlock(256, 512, [2, 1]),
            ResNetBasicBlock(512, 512, 1),

            ResNetBasicBlock(512, 512, 1),
            ResNetBasicBlock(512, 512, 1),

            ResNetBasicBlock(512, 512, 1),
            ResNetBasicBlock(512, 512, 1),
        )

        self.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))

        self.fc = nn.Linear(512, 4)  # 用于分类，四分类

    def forward(self, x):
        x = x.to(torch.float32)  # RuntimeError: expected scalar type Double but found Float
        out = self.conv1(x)  # torch.Size([36, 64, 2, 251])
        out = self.layer1(out)  # torch.Size([36, 64, 2, 251])
        out = self.layer2(out)  # torch.Size([36, 128, 1, 126])
        out = self.layer3(out)  # torch.Size([36, 256, 1, 63])
        out = self.layer4(out)  # torch.Size([36, 512, 1, 32])
        out = self.avgpool(out)  # torch.Size([36, 512, 1, 1])
        out = out.reshape(x.shape[0], -1)  # torch.Size([36, 512])
        out = self.fc(out)  # torch.Size([36, 4])
        return out


class TransformerClassifier(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_layers, num_heads):
        super(TransformerClassifier, self).__init__()
        self.conv1 = nn.Conv2d(1, 16, 6, 2, 3)
        self.embedding = nn.Embedding(input_dim, hidden_dim)
        self.encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(hidden_dim, num_heads),
            num_layers
        )
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, x):
        # print(x.shape)
        # x = x.view(2, 500)
        # print(x.shape)
        embedded = self.embedding(x)  # torch.Size([2, 500, 256])

        encoded = self.encoder(embedded)  # torch.Size([2, 500, 256])

        pooled = F.avg_pool1d(encoded.permute(1, 2, 0), encoded.size(0)).squeeze(2)  # torch.Size([500, 256])

        output = self.fc(pooled)
        return output

class SAXS_ResNet18_1(nn.Module):
    def __init__(self):
        super(SAXS_ResNet18_1, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=6, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = nn.Sequential(
            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1)
        )

        self.layer2 = nn.Sequential(
            ResNetDownBlock(64, 128, [2, 1]),
            ResNetBasicBlock(128, 128, 1)
        )

        self.layer3 = nn.Sequential(
            ResNetDownBlock(128, 256, [2, 1]),
            ResNetBasicBlock(256, 256, 1)
        )

        self.layer4 = nn.Sequential(
            ResNetDownBlock(256, 1024, [2, 1]),
            ResNetBasicBlock(1024, 1024, 1)
        )

        self.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))

        self.fc = nn.Linear(1024, 1000)  # 输入transformer长度为1000

    def forward(self, x):
        # x = x.to(torch.float32)  # RuntimeError: expected scalar type Double but found Float
        out = self.conv1(x)  # torch.Size([36, 64, 2, 251])
        out = self.layer1(out)  # torch.Size([36, 64, 2, 251])
        out = self.layer2(out)  # torch.Size([36, 128, 1, 126])
        out = self.layer3(out)  # torch.Size([36, 256, 1, 63])
        out = self.layer4(out)  # torch.Size([36, 512, 1, 32])
        out = self.avgpool(out)  # torch.Size([36, 512, 1, 1])
        out = out.reshape(x.shape[0], -1)  # torch.Size([36, 512])
        out = self.fc(out)  # torch.Size([36, 4])
        return out


class SAXS_ResNet34_1(nn.Module):
    def __init__(self):
        super(SAXS_ResNet34_1, self).__init__()
        self.conv1 = nn.Conv2d(1, 64, kernel_size=6, stride=2, padding=3)
        self.bn1 = nn.BatchNorm2d(64)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = nn.Sequential(
            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1),

            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1),

            ResNetBasicBlock(64, 64, 1),
            ResNetBasicBlock(64, 64, 1)
        )

        self.layer2 = nn.Sequential(
            ResNetDownBlock(64, 128, [2, 1]),
            ResNetBasicBlock(128, 128, 1),

            ResNetBasicBlock(128, 128, 1),
            ResNetBasicBlock(128, 128, 1),

            ResNetBasicBlock(128, 128, 1),
            ResNetBasicBlock(128, 128, 1),

            ResNetBasicBlock(128, 128, 1),
            ResNetBasicBlock(128, 128, 1)
        )

        self.layer3 = nn.Sequential(
            ResNetDownBlock(128, 256, [2, 1]),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1),

            ResNetBasicBlock(256, 256, 1),
            ResNetBasicBlock(256, 256, 1),

            ResNetDownBlock(256, 512, [2, 1]),
            ResNetBasicBlock(512, 512, 1),

            ResNetBasicBlock(512, 512, 1),
            ResNetBasicBlock(512, 512, 1),

            ResNetBasicBlock(512, 512, 1),
            ResNetBasicBlock(512, 512, 1)
        )

        self.layer4 = nn.Sequential(
            ResNetDownBlock(512, 2048, [2, 1]),
            ResNetBasicBlock(2048, 2048, 1),

            ResNetBasicBlock(2048, 2048, 1),
            ResNetBasicBlock(2048, 2048, 1),

            ResNetBasicBlock(2048, 2048, 1),
            ResNetBasicBlock(2048, 2048, 1)
        )

        self.avgpool = nn.AdaptiveAvgPool2d(output_size=(1, 1))

        self.fc = nn.Linear(2048, 1000)  # 用于分类，四分类

    def forward(self, x):
        # x = x.to(torch.float32)  # RuntimeError: expected scalar type Double but found Float
        out = self.conv1(x)  # torch.Size([36, 64, 2, 251])
        out = self.layer1(out)  # torch.Size([36, 64, 2, 251])
        out = self.layer2(out)  # torch.Size([36, 128, 1, 126])
        out = self.layer3(out)  # torch.Size([36, 256, 1, 63])
        out = self.layer4(out)  # torch.Size([36, 512, 1, 32])
        out = self.avgpool(out)  # torch.Size([36, 512, 1, 1])
        out = out.reshape(x.shape[0], -1)  # torch.Size([36, 512])
        out = self.fc(out)  # torch.Size([36, 4])
        return out

# # 生成随机数矩阵测试网络
# fd = np.random.rand(36, 2, 500)
# # print(fd)
#
# fd = torch.as_tensor(fd)
# # fd = torch.LongTensor(fd)
# fd = torch.unsqueeze(fd, dim=1)  # 行升维
# print(fd.shape)
# # net = SAXS_ResNet34()
# # output = net(fd)
# # print(output)
# # 加载数据
# # data = pd.read_csv('A-SiO2-1C-1-test.txt', names=['q', 'iten'])
# data = np.loadtxt('./GOLD_20nm_test.txt')
# x = data[:, 0]
# x = np.array(x)
# # x = x / 10  # 横坐标缩小10倍
# # print(x)
# x = np.array(x).reshape(-1, 1)
# # print(x.shape)
# y = data[:, 1]
# y = np.array(y).reshape(-1, 1)
# # print(y.shape)
# data = np.append(y, x, axis=1)  # axis=0在竖直方向拼接
# print(data)
# print(data.shape)  # [2, 500]
# data = torch.LongTensor(data)
# print(data)
# # data = data.cuda()
# input_dim = 10000
# hidden_dim = 256
# output_dim = 4
# num_layers = 4
# num_heads = 8
# batch_size = 1
# # input_data = torch.zeros(batch_size, data.size(1), data.size(0))
# # input_data = torch.LongTensor(input_data)
# # print(input_data.shape)
# net = TransformerClassifier(input_dim, hidden_dim, output_dim, num_layers, num_heads)
# # net = net.cuda()
# output = net(data)
# print(output)
# print(output.shape)  # torch.Size([500, 4])

