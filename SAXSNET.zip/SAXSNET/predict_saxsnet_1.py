import torch
from PIL import Image
from SAXS_Resnet18 import SAXS_ResNet34
from SAXS_Resnet18 import SAXS_ResNet18_size
from SAXS_size_Net_2d import saxs_net
import pandas as pd
import numpy as np
from sklearn.decomposition import PCA
from sklearn.svm import SVR

# 加载数据
# data = pd.read_csv('A-SiO2-1C-1-test.txt', names=['q', 'iten'])
data = np.loadtxt('./sphere_gold_10nm.txt')
x = data[:, 0]
x = np.array(x)
# x = x / 10  # 横坐标缩小10倍
# print(x)
x = np.array(x).reshape(1, -1)
# print(x.shape)
y = data[:, 1]
y = np.array(y).reshape(1, -1)
# print(y.shape)
data = np.append(y, x, axis=0)  # axis=0在竖直方向拼接


print(data.shape)  # [2, 500]
data = torch.as_tensor(data)
data = torch.unsqueeze(data, dim=0)  # 行升维[1, 2, 500]
data = torch.unsqueeze(data, dim=0)  # 行升维[1, 1, 2, 500]
# data = data.cuda()

classes = ('cylinder', 'lamellar', 'parallelepiped', 'sphere')

# 实例化网络
NET = SAXS_ResNet34()
NET.eval()  # 测试时关闭dropout

# 加载模型文件
# checkpoint = torch.load('./saxs_test_2d_new.pth')
# state_dict = checkpoint('state_dict')
# NET.load_state_dict(state_dict, False)
NET.load_state_dict(
    torch.load('./pre_SAXS_ResNet34_autolr0.001_data5new_kflod5_200epoch_min.pth')
                    )

with torch.no_grad():
    outputs = NET(data)
    predict = torch.max(outputs, dim=1)[1].data.numpy()

print(outputs)
print(predict)
print("纳米颗粒的形状预测结果为：", classes[int(predict)])
