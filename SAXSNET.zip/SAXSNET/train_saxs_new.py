import os
import pathlib
import pandas as pd
import torch
import torch.nn as nn
import torch.utils.data as Data
import torchvision
from torch.utils.data import DataLoader
import torchvision.transforms as transforms
from torch.utils.data import random_split
import numpy as np
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
import torch.optim as optim
from SAXS_Net_2d_1 import saxs_net
import copy


# 测试载入数据
# # 定义Getloader类，继承Dataset方法，并重写__getitem__()和__lan__()方法
# class Getloader(torch.utils.data.Dataset):
#     # 初始化函数，得到数据
#     def __init__(self, data_root, data_label):
#         self.data = data_root
#         self.label = data_label
#
#     # index是根据batchsize划分数据后得到的索引，最后将data和对应的labels一起返回
#     def __getitem__(self, index):
#         data = self.data[index]
#         labels = self.label[index]
#         return data, labels
#
#     # 该函数返回数据大小长度，目的是Dataloader方便划分，如果不知道大小，Dataloader会糊涂
#     def __len__(self):
#         return len((2, 500))


# # 随机生成数据，大小为4*500
# source_data = np.random.rand(4, 500)
# # 随机生成标签，大小为2*1列
# source_label = np.random.randint(0, 2, (2, 1))
# # 通过Getloader将数据进行加载，返回Dataset对象，包含data和labels
# torch_data = Getloader(source_data, source_label)
# # print(torch_data[0])
# # print(torch_data[1])
# datas = DataLoader(torch_data, batch_size=2, shuffle=True, drop_last=False)
# for i, data in enumerate(datas):
#     print("第{}个Batch \n{}".format(i, data))
#     print(data[0].shape)  # torch.Size([2, 500])


# 构建主函数main，多线程程序要放在主函数中训练
def main():
    # 定义Getloader类为了加载自己的数据，继承Dataset方法，并重写__getitem__()和__lan__()方法

    global val_set, train_set

    class Getloader(torch.utils.data.Dataset):
        # 初始化函数，得到数据
        def __init__(self, data_root, data_label):
            self.data = data_root
            self.label = data_label
            # self.transform = transform

        # index是根据batchsize划分数据后得到的索引，最后将data和对应的labels一起返回
        def __getitem__(self, index):
            data = self.data[index]
            labels = self.label[index]
            return data, labels

        # 该函数返回数据大小长度，目的是Dataloader方便划分，如果不知道大小，Dataloader会糊涂
        def __len__(self):
            return len(self.data)

    # 提取横坐标
    # d = pd.read_csv('./data/cylinder_Iq.csv', header=None, encoding='utf-8')
    # x = d.loc[0]
    x = np.linspace(0.01, 4, 500)
    x = np.array(x).reshape(1, -1)
    # print(x)

    # 加载数据
    print('开始加载数据............')
    data_path = 'data4'
    data_suffix = '_Iq.csv'

    def get_data_files():
        return pathlib.Path(data_path).glob('*' + data_suffix)

    def preprocess_input_file(filename):
        input_df = pd.read_csv(filename)
        input_df.rename(columns={input_df.columns[0]: 'id'}, inplace=True)
        return input_df

    #
    # data_files = get_data_files()
    # print(data_files)

    content = []
    for txt_file in get_data_files():
        filename = os.path.basename(txt_file)
        # log_verbose(' Retrieving data from: ' + filename)
        # read in data
        shape = preprocess_input_file(txt_file)  # preprocess_input_file预处理输入数据
        # add 'shape' column with shape name
        shape['shape'] = filename[:-len(data_suffix)]  # shape形状
        content.append(shape)
        # print(content)

    all_df = pd.concat(content, axis=0, ignore_index=True)  # pd.concat()函数可以沿着指定的轴将多个dataframe或者series拼接到一起。
    # print(all_df)

    # 创建一个包含除目标列之外的所有训练数据的数据框架
    all_x = all_df.drop(columns=['id', 'shape'])
    # print(all_x)

    # # 测试合并
    # test1 = np.zeros(shape=(2, 500))  # 创建（2,500）的零矩阵
    # y = all_x.loc[0]
    # y = np.array(y).reshape(1, -1)
    # inputs = np.append(y, x, axis=0)
    # print(inputs)

    # 创建一个只有目标列的dataframe
    all_y = all_df[['shape']]

    # all_y = np.array(all_y)
    # all_y = torch.as_tensor(all_y.values)

    # all_y = pd.get_dummies(all_y)
    # print(all_y)
    #       cylinder  disk   flat_hollow_cylinder    sphere
    #            0      1          2                    3

    # 将字符串类型编码为整型
    laber_encoder = LabelEncoder()
    laber_encoder = laber_encoder.fit(all_y.values.ravel())
    val_set = laber_encoder.transform(all_y.values.ravel())
    classes = all_df['shape'].unique()
    print(classes)
    # classes_en = val_set.unique()
    # print(classes_en)
    print(val_set)
    # val_set = torch.nn.functional.one_hot(all_y)

    # 合并数据
    print('开始合并数据..................')
    num = all_x.shape[0]
    # num1 = x_test.shape[0]
    train_set = np.zeros(shape=(2, 500))  # 创建（2,500）的零矩阵
    train_set = torch.as_tensor(train_set)
    train_set = torch.unsqueeze(train_set, dim=0)  # 行升维
    # val_set = np.zeros(shape=(2, 500))  # 创建（2,500）的零矩阵

    for i in range(num):
        # print(i+1)
        y = all_x.loc[i]
        y = np.array(y).reshape(1, -1)
        a = np.append(y, x, axis=0)  # axis=0在竖直方向拼接
        a = torch.as_tensor(a)
        a = torch.unsqueeze(a, dim=0)  # 行升维
        train_set = np.append(train_set, a, axis=0)
        if i % 500 == 0:
            print(a.shape, '合并第 %d 次' % i)
        # break
    train_set = np.delete(train_set, 0, axis=0)  # 删除第0行
    print(train_set.shape)  # 行升维后(12000, 2, 500)

    # # 归一化和标准化
    # transform_compose = transforms.Compose([
    #     transforms.ToTensor(),  # 归一化
    #     transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])  # 标准化
    # ])

    # train_set = transform_compose(train_set)
    # val_set = transform_compose(val_set)

    print('数据合并完毕!!')

    # 分割数据
    test_size = 0.2
    x_train, x_test, y_train, y_test = train_test_split(train_set, val_set, test_size=test_size)
    # y_train, y_test = train_test_split(val_set, test_size=test_size)
    # x_train, x_test = random_split(dataset=train_set, lengths=[9, 1])
    # y_train, y_test = random_split(dataset=laber_encoder_y, lengths=[9, 1])

    transform = transforms.Compose([transforms.ToTensor(), transforms.Resize((2, 500)),
                                    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    # transforms.Normalize 对数据进行标准化

    # train_data = Getloader(x_train, y_train, transform=transform)
    train_data = Getloader(x_train, y_train)
    val_data = Getloader(x_test, y_test)

    # # print(type(x_train))
    # print(x_train.shape)
    print('分割数据完毕！！')

    # # 合并数据
    # num = x_train.shape[0]
    # num1 = x_test.shape[0]
    # train_set = np.zeros(shape=(2, 500))  # 创建（2,500）的零矩阵
    # val_set = np.zeros(shape=(2, 500))  # 创建（2,500）的零矩阵
    #
    # for i in range(num):
    #     # print(i+1)
    #     y = x_train.loc[i]
    #     y = np.array(y).reshape(1, -1)
    #     a = np.append(y, x, axis=0)  # axis=0在竖直方向拼接
    #     train_set = np.append(train_set, a, axis=0)
    #     # break
    # # print(train_set)
    # # print(train_set.shape)
    #
    # for j in range(num1):
    #
    #     y1 = x_test.loc[j]
    #     y1 = np.array(y1).reshape(1, -1)
    #     b = np.append(y1, x, axis=0)
    #     val_set = np.append(val_set, b, axis=0)
    #
    # train_set = np.delete(train_set, [0, 1], axis=0)  # 删除第0，1列
    # val_set = np.delete(val_set, [0, 1], axis=0)
    # # print(train_set)
    # # print(train_set.shape)
    # print('数据合并完毕!!')

    # 把数据加载到dataloader

    # datasets = Getloader(train_set, val_set)
    # train_data, val_data = random_split(dataset=datasets, lengths=[7, 3])  # 分割数据集

    # 加载数据

    train_loader = torch.utils.data.DataLoader(train_data, batch_size=16,  # 分批次训练，每一次拿出36张图片进行训练
                                               shuffle=True, num_workers=0)  # shuffle 是否将数据集打乱
    val_loader = torch.utils.data.DataLoader(val_data, batch_size=16,
                                             shuffle=True, num_workers=0)
    val_data_iter = iter(val_loader)  # 设置迭代器
    val_image, val_label = val_data_iter.next()

    # 开始训练
    print('开始训练...................')
    # 实例化网络
    net = saxs_net()
    if torch.cuda.is_available():
        net = net.cuda()

    # 验证数据转为cuda
    val_image = val_image.unsqueeze(1)
    val_image = val_image.cuda()

    val_label = val_label.to(torch.int64)
    val_label = val_label.cuda()

    # 设置损失函数
    loss_function = nn.CrossEntropyLoss()  # CrossEntropyLoss()函数包含logsoftmax和NLLLose函数
    # loss_function = nn.MSELoss()
    if torch.cuda.is_available():
        loss_function = loss_function.cuda()

    # 设置优化器
    optimizer = optim.Adam(net.parameters(), lr=0.0001, weight_decay=0.01)  # 传入训练参数，学习率，L2正则化（weight_decay=0.01）

    # 训练过程
    for epoch in range(60):  # 将训练集迭代10次

        running_loss = 0.0
        for step, data in enumerate(train_loader, start=0):

            inputs, labels = data
            inputs = inputs.unsqueeze(1)
            # print(inputs)
            # print(inputs.shape)
            # print(labels.shape, 'labels')

            inputs = inputs.cuda()
            labels = labels.to(torch.int64)
            labels = labels.cuda()
            # print(labels.shape)

            outputs = net(inputs)
            # print(outputs.shape)
            loss = loss_function(outputs, labels)
            # 通过损失函数计算损失，outputs对应网络预测的值，labels对应图片的真实标签

            # 梯度清零
            optimizer.zero_grad()
            # 前向传播、反向传播、参数更新
            loss.backward()  # 将得到的损失值反向传播
            optimizer.step()  # 通过优化器进行参数的更新

            # 打印统计信息
            running_loss += loss.item()
            if step % 500 == 499:
                with torch.no_grad():
                    net.eval()  # 关闭Dropout层
                    outputs = net(val_image)  # [batch, 4], 正向传播
                    predict_y = torch.max(outputs, dim=1)[1]  # 网络预测最可能是哪个类别，然后找到对应的下标索引
                    accuracy = torch.eq(predict_y, val_label).sum().item() / val_label.size(0)
                    # 预测的标签类别与真实标签类别进行比较，相同的返回1/true， 不同的返回0/false，
                    # 且求和得到本次预测过程中，准确预测的样本比例，最终结果的形式是张量

                    print('[%d, %5d] train_loss: %.3f  test_accurary: %.3f' %
                          (epoch + 1, step + 1, running_loss / 500, accuracy))
                    # 打印出迭代次数，某次迭代具体哪一步，每500步的平均训练误差，测试样本的准确率

                    running_loss = 0.0  # 将训练误差归零，进行下500步的迭代过程

    print('Finished Training !!')

    # 保存模型
    save_path = './saxs_test_2d_3drop331L3_lr0.0001_newdata3.pth'
    torch.save(net.state_dict(), save_path)

    # 保存最优模型
    save_path = './saxs_test_2d_3drop331L3_lr0.0001_best_newdata3.pth'
    best_net_state = copy.deepcopy(net.state_dict())
    torch.save(best_net_state, save_path)


if __name__ == '__main__':
    main()
